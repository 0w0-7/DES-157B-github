new fullpage('#fullpage', {
    // Options
    autoScrolling: false,
    // scrollHorizontally: true,
    sectionsColor : ['#222222', '#222222', '#222222', '#222222', '#222222', '#222222', '#222222', '#222222', '#222222', '#222222'],
    navigation: true,
    slidesNavigation: true,

    anchors:['firstPage', 'secondPage', 'thirdPage', 'finalPage'],
    // Names each side dot
    navigationTooltips: ['Intro', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eigth', 'ninth', 'tenth'],
});

AOS.init({
    duration: 1200,
});


(function () {
	'use strict';

    const heartRateUpdate = [
        '',
        '100 BPM',
        '90 BPM',
        '80 BPM',
        '70 BPM',
        '60 BPM',
        '50 BPM',
        '40 BPM',
    ];

    const conditionUpdate = [
        '',
        'Short of breath, chest pain',
        'Seizure'
    ];
    // Select the elements for heart rate and condition display
    let heartRate = document.querySelector('#bpm');
    let condition = document.querySelector('#patientMonitor p');

    // Select all sections
	let sections = document.querySelectorAll('.section');

	let postTops = [];// Array to store top positions of sections
	let pageTop; // Variable to store the current scroll position
	let counter = 0;  // Counter to track current section
	let prevCounter = -1;  // Previous counter value to detect changes


    // Function to reset the positions of sections
	function resetPagePosition() {
		postTops = [];
		 // Calculate the top position of each section and store in postTops
		sections.forEach((section) => {
			postTops.push(Math.floor(section.getBoundingClientRect().top) + window.scrollY);
		});


        // Adjust the counter based on the current scroll position
		const pagePosition = window.scrollY + 300;
		counter = 0;
		postTops.forEach((post, index) => {
			if (pagePosition > post) {
				counter = index;
			}
		});
	}

    // Function to update heart rate and condition based on the current section
	function updateInfo(counter) {
		heartRate.textContent = heartRateUpdate[counter % heartRateUpdate.length];
		condition.textContent = conditionUpdate[counter % conditionUpdate.length];
	}

    // Event listener for scroll events
	window.addEventListener('scroll', () => {
		pageTop = window.scrollY + 300; // Calculate the adjusted scroll position

		// Determine the current section based on scroll position
		for (let i = 0; i < postTops.length; i++) {
			if (pageTop > postTops[i]) {
				counter = i;
			}
		}

        // If the section has changed, update the info and previous counter
		if (counter !== prevCounter) {
			updateInfo(counter);
			prevCounter = counter;
		}
	});

    // Event listener for resize events to recalculate section positions
	window.addEventListener('resize', () => {
		resetPagePosition();  // Recalculate section positions on window resize
	});


    // Initial call to set up the page positions
	resetPagePosition();

})(); // END IIFE